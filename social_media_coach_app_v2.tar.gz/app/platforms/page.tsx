
import { redirect } from 'next/navigation'

export default function PlatformsPage() {
  redirect('/dashboard')
}
